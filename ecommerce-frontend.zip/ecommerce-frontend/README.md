# 🛒 Online Bidding System — Frontend (React)
## ✅ COMPLETE — All files included, ready to run!

---

## 📋 Prerequisites
- **Node.js** (v16 or above) → https://nodejs.org
- **VS Code** → https://code.visualstudio.com

---

## 🚀 Steps to Run in VS Code

### Step 1 — Open the project
VS Code → File → Open Folder → Select `ecommerce-frontend` folder

### Step 2 — Open Terminal
Terminal → New Terminal  (or press Ctrl + `)

### Step 3 — Install dependencies
```
npm install
```
Wait 1–2 minutes for packages to download.

### Step 4 — Start the app
```
npm start
```
App opens automatically at **http://localhost:3000**

---

## ⚙️ Important
- The frontend connects to backend at **http://localhost:8080**
- Make sure Spring Boot backend is running BEFORE using the app
- Backend must be running for login, products, categories to load

---

## 📁 Complete Project Structure
```
ecommerce-frontend/
├── public/
│   ├── index.html
│   ├── favicon.ico
│   ├── logo192.png
│   ├── logo512.png
│   ├── manifest.json
│   └── robots.txt
├── src/
│   ├── images/
│   │   ├── carousel_1.png
│   │   ├── e_logo.png
│   │   └── star.png
│   ├── CategoryComponent/        (5 files) ✅
│   ├── NavbarComponent/          (8 files) ✅
│   ├── UserComponent/            (8 files) ✅
│   ├── PageComponent/            (4 files) ✅
│   ├── ProductComponent/         (8 files) ✅
│   ├── OrderComponent/           (5 files) ✅
│   ├── ProductOfferComponent/    (2 files) ✅
│   ├── App.js / App.css
│   ├── index.js / index.css
│   └── setupTests / reportWebVitals
└── package.json
```

---

## 👥 User Roles
The app supports 4 roles — login via `/user/login`:
- **Admin** — manage categories, products, orders, users
- **Customer** (Seller) — add products, manage bids, orders, wallet
- **Delivery** — view and update assigned delivery orders

