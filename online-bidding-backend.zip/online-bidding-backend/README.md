# 🏷️ Online Bidding System — Backend (Spring Boot)

## 📋 Prerequisites
- Java JDK 17 — Download from https://adoptium.net
- Eclipse IDE for Enterprise Java — Download from https://www.eclipse.org/downloads/
- MySQL (v8.x) — Download from https://dev.mysql.com/downloads/installer/
- Maven (bundled with project via mvnw)

---

## ⚙️ Before Running — Setup Steps

### Step 1 — Setup MySQL
1. Open MySQL Workbench or MySQL command line
2. Make sure MySQL is running on port **3306**
3. The database `online_bidding_system` will be **created automatically** on first run

### Step 2 — Update application.properties
Open: `src/main/resources/application.properties`

Change the password to YOUR MySQL password:
```
spring.datasource.password=YOUR_MYSQL_PASSWORD_HERE
```

Change the image upload path to a folder on YOUR computer:
```
com.onlinebidding.image.folder.path=C:/Users/YourName/Desktop/images
```
Then create that folder manually on your computer.

---

## 🚀 Steps to Run in Eclipse

### Step 1 — Import the project
1. Open Eclipse
2. File → Import → Maven → Existing Maven Projects
3. Browse to the `online-bidding-backend` folder
4. Click Finish — wait for Maven to download dependencies (may take 2-3 minutes)

### Step 2 — Run the application
1. Expand the project in Package Explorer
2. Navigate to: `src/main/java` → find the main class (ends with `Application.java`)
3. Right-click it → Run As → Spring Boot App

### Step 3 — Verify it's running
Open browser and go to: **http://localhost:8080/swagger-ui.html**
You should see the Swagger API documentation page.

---

## 🔧 Tech Stack
| Technology | Version |
|---|---|
| Java | 17 |
| Spring Boot | 3.2.0 |
| Spring Security + JWT | 6.2.0 / jjwt 0.11.5 |
| MySQL | 8.x |
| Hibernate / JPA | 6.3.1 |
| Swagger (SpringDoc) | 2.2.0 |
| Lombok | 1.18.30 |
| Maven | 3.9.5 |

---

## ⚠️ Missing File — pom.xml & Java Source Code
The Java source files (`src/main/java/`) and `pom.xml` still need to be added.
Place all Java source files inside: `src/main/java/com/biddingsystem/`

---

## 📁 Project Structure
```
online-bidding-backend/
├── .mvn/wrapper/
│   ├── maven-wrapper.jar
│   └── maven-wrapper.properties
├── .settings/              ← Eclipse IDE settings
├── src/
│   └── main/
│       ├── java/           ← PUT YOUR JAVA SOURCE FILES HERE
│       │   └── com/biddingsystem/
│       │       ├── controller/
│       │       ├── service/
│       │       ├── model/
│       │       ├── repository/
│       │       └── *Application.java
│       └── resources/
│           ├── application.properties
│           └── log4j2-spring.xml
├── pom.xml                 ← STILL NEEDED
└── .gitignore
```
